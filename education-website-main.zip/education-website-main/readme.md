### Education website for College & University
.
![Education website template](https://i.ibb.co/0Yr6dLg/education.png)
.
.
This is a HTML5 Responsive site template suitable for Courses, colleges, Workshop, Lessons and university sites. In this educational website we have't used any framework, totally based on core languages like HTML & CSS.
.
.
.
.
### features
- Valid and clean HTML5/CSS3 code
- 5 different pages
- Google Map
- Free Fonts from Google Fonts
- Free Icons from Font Awesome
- Crossover Browsers Compatibility
- Free Future Updates
- etc
.
.
.
.
.

[![Nihory - Portfolio site template live demo](https://i.ibb.co/vwN8cgW/live-demo.png)](https://education-atulcodex.netlify.app/)
.
.
.
.
.
[![Atul - Buy Me A Coffee](https://i.ibb.co/7rR9S4L/buy-me-a-coffee.png)](https://www.buymeacoffee.com/atulcodex)